package com.example.taskmanager;

import java.time.LocalDate;

public class Task {
    private String title;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;

    public void setStatus(String status) {
        this.status = status;
    }

    private String status;

    public Task(String title, String description, LocalDate startDate, LocalDate endDate, String status) {
        this.title = title;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return title;
    }
}
