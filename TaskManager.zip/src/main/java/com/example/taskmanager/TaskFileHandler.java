package com.example.taskmanager;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TaskFileHandler {

    public static void saveTasksToFile(List<Task> tasks, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Task task : tasks) {
                writer.write(task.getTitle() + "|" + task.getDescription() + "|" +
                        task.getStartDate() + "|" + task.getEndDate() + "|" + task.getStatus() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Task> loadTasksFromFile(String filePath) {
        List<Task> tasks = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] taskData = line.split("\\|");
                if (taskData.length >= 5) {
                    String title = taskData[0];
                    String description = taskData[1];
                    LocalDate startDate = LocalDate.parse(taskData[2]);
                    LocalDate endDate = LocalDate.parse(taskData[3]);
                    String status = taskData[4];

                    Task task = new Task(title, description, startDate, endDate, status);
                    tasks.add(task);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return tasks;
    }
}
