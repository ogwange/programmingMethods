package com.example.taskmanager;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.kordamp.bootstrapfx.BootstrapFX;
import org.kordamp.bootstrapfx.scene.layout.Panel;

import java.io.File;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

public class TaskManagerApp extends Application {
    private ObservableList<Task> tasks = FXCollections.observableArrayList();
    private ListView<Task> taskListView = new ListView<>();
    private Label taskDetailsLabel = new Label();
    private Stage primaryStage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Task Manager");

//        addDummyTasks();
        // Create and display the initial scene (Home page)
        Scene homeScene = createHomePage();
        primaryStage.setScene(homeScene);
        primaryStage.show();
    }

    private void addDummyTasks() {
        addTaskToTaskList("Finish Project", "Complete the final report", LocalDate.of(2023, 8, 15), LocalDate.of(2023, 8, 20), "In Progress");
        addTaskToTaskList("Meeting", "Discuss project updates with team", LocalDate.of(2023, 8, 17), LocalDate.of(2023, 8, 17), "Completed");
        addTaskToTaskList("Prepare Presentation", "Create slides for client presentation", LocalDate.of(2023, 8, 18), LocalDate.of(2023, 8, 19), "In Progress");
        addTaskToTaskList("Review Code", "Review and refactor codebase", LocalDate.of(2023, 8, 20), LocalDate.of(2023, 8, 22), "Not Started");
    }

    private Scene createHomePage() {
        // Create UI elements for the Home page
        Panel panel = new Panel("Task Management");
        panel.getStyleClass().add("panel-primary");

        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);  // Align content in the center
        content.setPadding(new Insets(20));

        Label descriptionLabel = new Label("Welcome to Task Manager. Organize and track your tasks efficiently.");
        descriptionLabel.getStyleClass().add("lead");

        Button viewTasksButton = new Button("View Tasks");
        viewTasksButton.getStyleClass().setAll("btn", "btn-danger");
        viewTasksButton.setOnAction(e -> showTaskList());

        content.getChildren().addAll(descriptionLabel, viewTasksButton);
        content.setSpacing(20);

        // Create the brief guide
//        VBox guideBox = new VBox(
                Label title = new Label("Getting Started:");
                title.getStyleClass().add("lead");
                Label desc1 = new Label("1. View Tasks: Click 'View Tasks' to see your task list.");
                Label desc2 = new Label("2. Add Tasks: Navigate to 'Create Task' to create new tasks.");
                Label desc3 = new Label("3. Update Tasks: In the task details, edit and update task information.");
//        );
        Label copyrightLabel = new Label("Copyright 2023 - Ogwang Emmanuel KS22M10/001 A98518");
        copyrightLabel.getStyleClass().add("italic");
        copyrightLabel.getStyleClass().add("strong");
        copyrightLabel.getStyleClass().add("text-mute");



        // Combine content and guide in a vertical layout
        VBox layout = new VBox(content, title, desc1, desc2, desc3, copyrightLabel);  // Swap the order

        layout.setAlignment(Pos.CENTER);  // Center the entire content
        layout.setSpacing(20);  // Add spacing between content and guide

        panel.setBody(layout);

        // Create the layout
        StackPane homeLayout = new StackPane();  // Use StackPane as the root layout
        homeLayout.setPadding(new Insets(20));
        homeLayout.getChildren().add(panel);     // Add the panel to the StackPane

        Scene scene = new Scene(homeLayout, 800, 600);
        scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());
        return scene;
    }

    private Scene createTaskListPage() {
        // Create UI elements for the Task List page
        TableView<Task> tableView = createTaskTableView();
        tableView.setItems(tasks);

        tableView.setOnMouseClicked(e -> {
            Task selectedTask = tableView.getSelectionModel().getSelectedItem();
            if (selectedTask != null) {
                showTaskDetails(selectedTask);
            }
        });

        Panel panel = new Panel("Task List");
        panel.getStyleClass().add("panel-primary");

        tableView.getStyleClass().add("table"); // Apply Bootstrap table class

        panel.setBody(tableView);  // Set the TableView as the body of the Panel

        // Create the layout
        BorderPane taskListLayout = new BorderPane();
        taskListLayout.setTop(createMenuBar());
        taskListLayout.setCenter(panel);  // Set the Panel as the center of the layout

        Scene taskListScene = new Scene(taskListLayout, 800, 600);
        taskListScene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());
        return taskListScene;
    }


    private TableView<Task> createTaskTableView() {
        TableView<Task> tableView = new TableView<>();

        TableColumn<Task, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<Task, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));

        TableColumn<Task, String> statusColumn = new TableColumn<>("Status");
//        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusColumn.setCellFactory(column -> new TableCell<Task, String>() {
            @Override
            protected void updateItem(String status, boolean empty) {
                super.updateItem(status, empty);

                getStyleClass().removeAll("bg-danger", "bg-success", "bg-warning", "text-white", "text-dark");

                if (status == null || empty) {
                    setText(null);
                    setGraphic(null);
                } else {
                    setText(status);

                    if ("Not Started".equals(status)) {
                        getStyleClass().addAll("bg-danger", "text-white");
                    } else if ("Completed".equals(status)) {
                        getStyleClass().addAll("bg-success", "text-white");
                    } else if ("In Progress".equals(status)) {
                        getStyleClass().addAll("bg-warning", "text-dark");
                    }
                }
            }
        });

        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));


        TableColumn<Task, LocalDate> startDateColumn = new TableColumn<>("Start Date");
        startDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        TableColumn<Task, LocalDate> endDateColumn = new TableColumn<>("Start Date");
        endDateColumn.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        // Apply Bootstrap table class to the TableView
        tableView.getStyleClass().add("table");

        // Set percentage-based column widths
        titleColumn.prefWidthProperty().bind(tableView.widthProperty().multiply(0.25));
        descriptionColumn.prefWidthProperty().bind(tableView.widthProperty().multiply(0.35));
        statusColumn.prefWidthProperty().bind(tableView.widthProperty().multiply(0.15));
        startDateColumn.prefWidthProperty().bind(tableView.widthProperty().multiply(0.25));

        // Add the columns to the table view
        tableView.getColumns().addAll(titleColumn, descriptionColumn, statusColumn, startDateColumn, endDateColumn);

        return tableView;
    }

    private Scene createTaskDetailsPage(Task selectedTask, ObservableList<Task> taskList) {
        // Create content
        VBox taskDetailsLayout = new VBox();
        taskDetailsLayout.setPadding(new Insets(20));
        taskDetailsLayout.setSpacing(10);

        Label titleLabel = new Label("Title: " + selectedTask.getTitle());
        Label descriptionLabel = new Label("Description: " + selectedTask.getDescription());
        Label startDateLabel = new Label("Start Date: " + selectedTask.getStartDate());
        Label endDateLabel = new Label("End Date: " + selectedTask.getEndDate());
        Label statusLabel = new Label("Status: " + selectedTask.getStatus());

        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getStyleClass().addAll("form-control");
        statusComboBox.getItems().addAll("Not Started", "In Progress", "Completed");
        statusComboBox.setValue(selectedTask.getStatus());
        statusComboBox.setOnAction(e -> {
            String newStatus = statusComboBox.getValue();
            selectedTask.setStatus(newStatus);
            statusLabel.setText("Status: " + newStatus);
        });

        // Apply Bootstrap styles
        titleLabel.getStyleClass().addAll("h4", "text-primary");
        descriptionLabel.getStyleClass().addAll("text-muted");
        startDateLabel.getStyleClass().addAll("text-muted");
        endDateLabel.getStyleClass().addAll("text-muted");
        statusLabel.getStyleClass().addAll("text-muted");

//        Button deleteButton = new Button("Delete Task");
//        deleteButton.getStyleClass().addAll("btn", "btn-danger");
//        deleteButton.setOnAction(e -> {
//            // Remove the selected task from the taskList
//            taskList.remove(selectedTask);
//            // You might want to navigate back to the previous page or handle UI updates here
//            showTaskList();
//        });
        Button deleteButton = new Button("Delete Task");
        deleteButton.getStyleClass().addAll("btn", "btn-danger");
        deleteButton.setOnAction(e -> {
            Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmationAlert.initModality(Modality.APPLICATION_MODAL);
            confirmationAlert.setTitle("Confirm Deletion");
            confirmationAlert.setHeaderText("Confirm Task Deletion");
            confirmationAlert.setContentText("Are you sure you want to delete the selected task?");

            // Customize the button types (options) of the confirmation dialog
            ButtonType confirmButton = new ButtonType("Delete");
            ButtonType cancelButton = new ButtonType("Cancel");
            confirmationAlert.getButtonTypes().setAll(confirmButton, cancelButton);

            // Show the confirmation dialog and wait for user response
            ButtonType userResponse = confirmationAlert.showAndWait().orElse(ButtonType.CANCEL);

            if (userResponse == confirmButton) {
                // User confirmed the deletion, so proceed with task removal
                taskList.remove(selectedTask);
                // You might want to navigate back to the previous page or handle UI updates here
                showTaskList();
            }
        });

        taskDetailsLayout.getChildren().addAll(titleLabel, descriptionLabel, startDateLabel, endDateLabel, statusLabel, statusComboBox, deleteButton);

        // Create a BootstrapFX panel with panel-primary class
        Panel panel = new Panel("Task Details");
        panel.getStyleClass().add("panel-primary");

        panel.setBody(taskDetailsLayout);
        // Create the top menu bar
        MenuBar menuBar = createMenuBar();

        // Create a VBox to hold the menu and the content
        VBox contentContainer = new VBox(menuBar, panel);
        contentContainer.getStyleClass().add("container");

        // Create a scene with BootstrapFX styles
        Scene scene = new Scene(contentContainer, 800, 600);
        scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

        return scene;
    }

    private Scene createNewTaskPage(ObservableList<Task> tasks) {
        // Create content
        VBox newTaskLayout = new VBox();
        newTaskLayout.setPadding(new Insets(20));
        newTaskLayout.setSpacing(10);

        Label titleLabel = new Label("Title:");
        TextField titleTextField = new TextField();

        Label descriptionLabel = new Label("Description:");
        TextField descriptionTextField = new TextField();

        Label startDateLabel = new Label("Start Date:");
        DatePicker startDatePicker = new DatePicker();

        Label endDateLabel = new Label("End Date:");
        DatePicker endDatePicker = new DatePicker();

        // Apply Bootstrap styles
        titleLabel.getStyleClass().addAll("h4", "text-primary");

        // Create a button to save the new task
        Button saveButton = new Button("Save");
        saveButton.getStyleClass().addAll("btn", "btn-primary");
        saveButton.setOnAction(e -> {
            String title = titleTextField.getText();
            String description = descriptionTextField.getText();
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();
            String status = "Not Started";

            if (title.isEmpty() || startDate == null || endDate == null || startDate.isAfter(endDate)) {
                // Display error alert for each condition
                if (title.isEmpty()) {
                    showErrorAlert("Title is required.");
                }
                if (startDate == null || endDate == null) {
                    showErrorAlert("Both Start Date and End Date are required.");
                }
                if (startDate != null && endDate != null && startDate.isAfter(endDate)) {
                    showErrorAlert("End Date should not be earlier than Start Date.");
                }
                return;
            }

            Task newTask = new Task(title, description, startDate, endDate, status);
            tasks.add(newTask);

            // Clear input fields after saving
            titleTextField.clear();
            descriptionTextField.clear();
            startDatePicker.setValue(null);
            endDatePicker.setValue(null);

            showTaskList();
        });

        newTaskLayout.getChildren().addAll(
                titleLabel, titleTextField,
                descriptionLabel, descriptionTextField,
                startDateLabel, startDatePicker,
                endDateLabel, endDatePicker,
                saveButton
        );

        // Create a BootstrapFX panel with panel-primary class
        Panel panel = new Panel("Create New Task");
        panel.getStyleClass().add("panel-primary");

        panel.setBody(newTaskLayout);

        // Create the top menu bar
        MenuBar menuBar = createMenuBar();

        // Create a VBox to hold the menu and the content
        VBox contentContainer = new VBox(menuBar, panel);
        contentContainer.getStyleClass().add("container");

        // Create a scene with BootstrapFX styles
        Scene scene = new Scene(contentContainer, 800, 600);
        scene.getStylesheets().add(BootstrapFX.bootstrapFXStylesheet());

        return scene;
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private MenuBar createMenuBar() {
        MenuBar menuBar = new MenuBar();
        Menu taskMenu = new Menu("Tasks");
        MenuItem homeMenuItem = new MenuItem("Home");
        MenuItem viewMenuItem = new MenuItem("View Task Lists");
        MenuItem createMenuItem = new MenuItem("Create Task");
        MenuItem saveMenuItem = new MenuItem("Save");
        MenuItem loadMenuItem = new MenuItem("Open");
        MenuItem exitMenuItem = new MenuItem("Exit");

        taskMenu.getItems().addAll(homeMenuItem, viewMenuItem, createMenuItem, saveMenuItem, loadMenuItem, exitMenuItem);
        menuBar.getMenus().add(taskMenu);

        // Set actions for menu items
        homeMenuItem.setOnAction(e -> showHomePage());
        viewMenuItem.setOnAction(e -> showTaskList());
        createMenuItem.setOnAction(e -> showCreateNewTaskPage(tasks));
        exitMenuItem.setOnAction(e -> System.exit(0));

        // Save tasks to a .txt file
        saveMenuItem.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Tasks to .txt File");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", "*.txt"));
            File file = fileChooser.showSaveDialog(menuBar.getScene().getWindow());

            if (file != null) {
                TaskFileHandler.saveTasksToFile(tasks, file.getAbsolutePath());
            }
        });

        // Load tasks from a .txt file
        loadMenuItem.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Load Tasks from .txt File");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", "*.txt"));
            File file = fileChooser.showOpenDialog(menuBar.getScene().getWindow());

            if (file != null) {
                List<Task> loadedTasks = TaskFileHandler.loadTasksFromFile(file.getAbsolutePath());
                tasks.clear();
                tasks.addAll(loadedTasks);
            }
        });

        return menuBar;
    }

    private void showHomePage() {
        Scene homeScene = createHomePage();
        primaryStage.setScene(homeScene);
    }

    private void showTaskList() {
        Scene taskListScene = createTaskListPage();
        primaryStage.setScene(taskListScene);
    }

    private void showTaskDetails(Task task) {
        Scene taskDetailsScene = createTaskDetailsPage(task, tasks);
        primaryStage.setScene(taskDetailsScene);
    }

    private void showCreateNewTaskPage(ObservableList<Task> tasks){
        Scene createNewTaskPage = createNewTaskPage(tasks);
        primaryStage.setScene(createNewTaskPage);
    }
    private void addTaskToTaskList(String title, String description, LocalDate startDate, LocalDate endDate, String status) {
        Task newTask = new Task(title, description, startDate, endDate, status);
        tasks.add(newTask);
        tasks.sort(Comparator.comparing(Task::getStartDate)); // Sort tasks by start date
        updateTaskListView();
    }

    private void updateTaskListView() {
        taskListView.setItems(tasks);
    }
}

